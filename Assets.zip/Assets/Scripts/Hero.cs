using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hero : MonoBehaviour
{
    [SerializeField] private float speed;
    [SerializeField] private float jumpForce;

    private Rigidbody2D rb; 
    private SpriteRenderer sprite;
    private Animator anima;

    private bool grounded;

    private States State
    {
        get { return (States)anima.GetInteger("status"); }
        set { anima.SetInteger("status", (int)value); }
    }
    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        sprite = GetComponentInChildren<SpriteRenderer>();
        anima = GetComponent<Animator>();
    }

    private void FixedUpdate()
    {
        CheckGround();
    }

    private void Update()
    {
        if (grounded) State = States.stand;
        rb.transform.Rotate(0, 0, 0);
        if (Input.GetButton("Horizontal"))
            Move();
        if (grounded && Input.GetButtonDown("Jump"))
        {
            anima.SetTrigger("prepare_jump");
            Jump();
        }
        if (!grounded) State = States.jump_go;

    }
    private void Move()
    {
        if (grounded) State = States.move;

        Vector3 horizontalInput = transform.right * Input.GetAxis("Horizontal");
        transform.position = Vector3.MoveTowards(transform.position, horizontalInput + transform.position, speed * Time.deltaTime);
        sprite.flipX = horizontalInput.x < 0.0f;


    }

    private void Jump()
    {
        rb.velocity = Vector2.up * jumpForce;

    }

    private void CheckGround()
    {
        Collider2D[] collider = Physics2D.OverlapCircleAll(transform.position, 0.3f);
        grounded = collider.Length > 1;
    }

}

public enum States
{
    stand,
    move,
    jump_go
}